<?php
function EsMultiploDe3($n){
	return ($n%3 == 0) ? true : false;
}
?>