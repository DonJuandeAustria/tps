<?php
include 'funcion.php';
$word = 'hola';
echo disorder($word);
?>