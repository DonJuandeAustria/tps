<?php
include 'funcion.php';
 $a = '1010101';
 $b = '0101010';
 $dist = hammingDistance($a, $b);
 echo $dist;
?>