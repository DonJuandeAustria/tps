<?php
$n1 = $_POST["n1"];
echo "Grados centigrados: $n1 <br/> Grados Fahrenheit: " . (($n1*9)/5)+32;
?>