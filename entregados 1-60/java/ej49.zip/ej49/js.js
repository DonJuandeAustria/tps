var num = prompt("Inserte un numero");
var i = 0;
while (i < num) {
    document.write ("Hola mundo")
    i++;

    if (i <num) {
        document.write ("<br>")
    }
}