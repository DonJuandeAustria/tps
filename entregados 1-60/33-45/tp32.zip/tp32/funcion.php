<?php
function intervalo($n1, $n2){
    return ($n1[0] < $n2) ? true : false;
}
?>  