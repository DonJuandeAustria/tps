<?php
    $n1 = $_POST["n1"];
    echo "Pies: $n1 <br/>Pulgadas: " . $n1*12 . "<br/>Yardas: " . $n1*3 . "<br/>Centímetros: " . $n1*2.54 . "<br/>Metros: " . $n1*2.54*100;   
?>