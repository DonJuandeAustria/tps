<?php
    $n = rand(1, 100);
    echo "Numero aleatorio: " . $n . "<br/>";
    if($n > 50){
        echo "Es mayor a 50";
    }else{
        echo "No es mayor a 50";
    }
?>