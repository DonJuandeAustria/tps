<?php
include_once("funcion.php");
$fecha = $_POST['fecha'];
 
echo calcularNewYear($fecha);
?>